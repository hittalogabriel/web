document.addEventListener("DOMContentLoaded", function () {
    // Botão "Contato" na navegação - rolar até o formulário
    const navContatoBtn = document.querySelector("nav .btn");
    navContatoBtn.addEventListener("click", function () {
        document.querySelector(".form-section").scrollIntoView({ behavior: "smooth" });
    });

    // Botão "Vamos Começar!" no cabeçalho - rolar até a seção de planos
    const headerBtn = document.querySelector("header .content .bttn");
    headerBtn.addEventListener("click", function () {
        const precoSection = document.querySelector(".preco");
        if (precoSection) {
            precoSection.scrollIntoView({ behavior: "smooth" });
        } else {
            alert("Confira nossos planos abaixo!");
        }
    });

    // Botões "Comece Agora" dos planos - exibir alerta com o nome do plano selecionado
    const planButtons = document.querySelectorAll(".preco .card .bttn");
    planButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            const card = this.closest(".card");
            const planName = card.querySelector("h4").textContent;
            alert("Você selecionou o plano " + planName + "!");
        });
    });

    // Interação no formulário de contato
    const form = document.querySelector(".cadastro form");
    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Impede o envio real do formulário
        const nomeInput = document.getElementById("nome");
        const emailInput = document.getElementById("email");

        if (nomeInput.value.trim() === "" || emailInput.value.trim() === "") {
            alert("Por favor, preencha todos os campos!");
        } else {
            alert("Obrigado, " + nomeInput.value + "! Recebemos sua mensagem.");
            form.reset(); // Limpa os campos do formulário
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    // Seleciona os links da navegação
    const navLinks = document.querySelectorAll("nav .nav-links li.link a");
    // Seleciona o elemento que contém "NOSSOS PLANOS" (título da seção de planos)
    const planosSection = document.querySelector("h2.header");

    // Adiciona evento de clique para cada link
    navLinks.forEach(function (link) {
        link.addEventListener("click", function (event) {
            // Obtém o texto do link clicado
            const linkText = this.textContent.trim();
            // Verifica se o link é "Preço" ou "Sobre Nós"
            if (linkText === "Preço" || linkText === "Sobre Nós") {
                event.preventDefault(); // Impede o comportamento padrão do link
                if (planosSection) {
                    // Rola suavemente até a seção de planos
                    planosSection.scrollIntoView({ behavior: "smooth" });
                }
            }
        });
    });
});

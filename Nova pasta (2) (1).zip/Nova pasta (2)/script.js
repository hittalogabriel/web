// Animar o cabeçalho
document.addEventListener("DOMContentLoaded", () => {
    const headerTitle = document.querySelector("header h1");
    const headerSubtitle = document.querySelector("header h4");
    const headerButton = document.querySelector("header .btn");

    // Animação de fade-in para o título
    setTimeout(() => {
        headerTitle.classList.add("fade-in");
    }, 500);

    // Animação de fade-in para o subtítulo
    setTimeout(() => {
        headerSubtitle.classList.add("fade-in");
    }, 1000);

    // Animação de fade-in para o botão
    setTimeout(() => {
        headerButton.classList.add("fade-in");
    }, 1500);
});

// Animação de Hover nos cartões de preço
const priceCards = document.querySelectorAll(".preco .card");

priceCards.forEach(card => {
    card.addEventListener("mouseenter", () => {
        card.classList.add("hover-effect");
    });
    card.addEventListener("mouseleave", () => {
        card.classList.remove("hover-effect");
    });
});

// Animação de Hover nos botões
const buttons = document.querySelectorAll(".btn");

buttons.forEach(button => {
    button.addEventListener("mouseenter", () => {
        button.classList.add("button-hover");
    });
    button.addEventListener("mouseleave", () => {
        button.classList.remove("button-hover");
    });
});
